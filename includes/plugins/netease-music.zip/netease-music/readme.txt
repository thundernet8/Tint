=== 网易云音乐 ===
Contributors: bigfa
Tags: wordpress,  163 ,music ,网易云音乐
Requires at least: 3.0
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

网易云音乐歌单

== Description ==

网易云音乐歌单，可以同步你在网易云音乐的歌单并播放。

音乐资源来自网易云音乐music.163.com

演示地址:http://fatesinger.com/music

插件使用帮助：http://fatesinger.com/74369

== Installation ==

1. 上传 `neatease-music`目录 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件
3. 后台填写你的网易云音乐用户ID
4. 直接使用短代码[nm]网易云音乐用户ID[/nm]，或者在需要的地方使用插入netease_music();


== Frequently asked questions ==



== Changelog ==

= 1.0.0 =
* 最初0.0.1版本发布

= 1.1.0 =
* 调用Wordpress 自带jquery库

= 1.2.0 =
* 增加后台设置选项
* 添加数据缓存

= 1.3.0 =
* 增加了专辑封面大小选择
* 播放列表单双列选择

= 1.4.0 = 
* 添加了歌词同步的选项
* 添加了播放条
* 添加了歌曲控制按钮
* 添加了专辑封面图宽度设置选项
* 隐藏了默认歌单（用户喜欢的歌曲）

= 1.5.0 = 
* 添加单曲播放器
* 精简了JS文件
* 部分CSS样式修正

= 1.5.1 = 
* 修改了播放器的代码位置，避免和文章列表样式冲突
* 修改默认缓存时间为1周
* 部分CSS样式修正

= 1.5.3 = 
* 部分CSS样式修正
* 点击专辑封面可以暂停播放

= 1.6.0 = 
* 采用AJAX方式加载更多专辑
* 部分CSS样式修正
* 增加了一个后台直接选择页面的方法
* 删除了单曲短代码
* 移除了无用JS文件
== Upgrade notice ==