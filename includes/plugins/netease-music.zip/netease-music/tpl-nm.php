<?php 
/*
Template Name: NM_Tmpl
*/
get_header();
?>
<?php netease_music();?>
<?php get_footer(); ?>
